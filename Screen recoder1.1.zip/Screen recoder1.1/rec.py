import wave
import sounddevice
from scipy.io.wavfile import write
fps = 44100
du = 10
print("recordind.....")
recorde = sounddevice.rec(int(du*fps),samplerate=fps,channels=2)
sounddevice.wait()
print("Done")
write("output.wav",fps,recorde)